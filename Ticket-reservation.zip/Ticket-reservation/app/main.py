from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI
from app.api.v1.events import router as events_router
from app.api.v1.reservations import router as reservations_router

app = FastAPI()

app.include_router(events_router, prefix="/api/v1")
app.include_router(reservations_router, prefix="/api/v1")
