# maintenance jobs

from app.db.session import pool

def expire_old_reservations():
    query = """
            UPDATE reservations
            SET status = 'expired'
            WHERE status = 'held'
              AND expires_at IS NOT NULL
              AND expires_at < NOW(); \
            """

    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(query)
            conn.commit()
