# transactional reservation logic

from datetime import datetime, timedelta
from fastapi import HTTPException
from psycopg import errors
from app.db.session import pool

def hold_seat(*, user_id, event_id, seat_id):
    expires_at = datetime.utcnow() + timedelta(minutes=10)

    with pool.connection() as conn:
        try:
            with conn.cursor() as cur:
                # Expire old holds
                cur.execute("""
                            UPDATE reservations
                            SET status = 'expired'
                            WHERE status = 'held'
                              AND expires_at < NOW();
                            """)

                # Lock seat
                cur.execute("""
                            SELECT id
                            FROM seats
                            WHERE id = %s
                                FOR UPDATE;
                            """, (seat_id,))

                if cur.fetchone() is None:
                    raise HTTPException(404, "Seat not found")

                # Insert reservation
                cur.execute("""
                            INSERT INTO reservations (
                                user_id, event_id, seat_id, status, expires_at
                            )
                            VALUES (%s, %s, %s, 'held', %s)
                            RETURNING id;
                            """, (user_id, event_id, seat_id, expires_at))

                reservation_id = cur.fetchone()[0]
                conn.commit()
                return reservation_id

        except errors.UniqueViolation:
            conn.rollback()
            raise HTTPException(409, "Seat already reserved")

        except Exception:
            conn.rollback()
            raise
