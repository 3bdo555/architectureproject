from fastapi import APIRouter, HTTPException
from app.db.session import pool

router = APIRouter()


@router.get("/health")
def health_check():
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1;")
                cur.fetchone()
    except Exception:
        raise HTTPException(status_code=503, detail="Database unavailable")

    return {"status": "ok"}
