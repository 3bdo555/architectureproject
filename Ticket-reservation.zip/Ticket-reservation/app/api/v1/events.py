from fastapi import APIRouter, HTTPException
from app.db.session import pool
from psycopg import errors

router = APIRouter()


@router.get("/events")
def list_events():
    query = """
            SELECT id, name, start_time
            FROM events
            ORDER BY start_time; \
            """

    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(query)
            rows = cur.fetchall()

    return [
        {
            "id": str(row[0]),
            "name": row[1],
            "start_time": row[2].isoformat(),
        }
        for row in rows
    ]


@router.post("/events")
def create_event(event: dict):
    name = event.get("name")
    start_time = event.get("start_time")
    venue_id = event.get("venue_id")

    if not all([name, start_time, venue_id]):
        raise HTTPException(
            status_code=400,
            detail="name, start_time, and venue_id are required",
        )

    query = """
            INSERT INTO events (name, start_time, venue_id)
            VALUES (%s, %s, %s)
                RETURNING id, name, start_time; \
            """

    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query, (name, start_time, venue_id))
                row = cur.fetchone()
                conn.commit()

    except errors.ForeignKeyViolation:
        raise HTTPException(status_code=400, detail="Invalid venue_id")

    except Exception:
        raise HTTPException(status_code=500, detail="Failed to create event")

    return {
        "id": str(row[0]),
        "name": row[1],
        "start_time": row[2].isoformat(),
    }
