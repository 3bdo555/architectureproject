from fastapi import APIRouter, HTTPException
from app.db.session import pool
from psycopg import errors

router = APIRouter()


@router.post("/reserve")
def reserve_ticket(payload: dict):
    event_id = payload.get("event_id")
    seat_id = payload.get("seat_id")
    user_id = payload.get("user_id")

    if not all([event_id, seat_id, user_id]):
        raise HTTPException(
            status_code=400,
            detail="event_id, seat_id, and user_id are required",
        )

    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                # start transaction
                cur.execute("BEGIN;")

                # lock seat
                cur.execute(
                    """
                    SELECT id
                    FROM seats
                    WHERE id = %s
                        FOR UPDATE;
                    """,
                    (seat_id,),
                )
                if not cur.fetchone():
                    raise HTTPException(400, "Seat not found")

                # check if already reserved
                cur.execute(
                    """
                    SELECT 1
                    FROM reservations
                    WHERE seat_id = %s;
                    """,
                    (seat_id,),
                )
                if cur.fetchone():
                    raise HTTPException(400, "Seat already reserved")

                # insert reservation
                cur.execute(
                    """
                    INSERT INTO reservations (event_id, seat_id, user_id)
                    VALUES (%s, %s, %s)
                    RETURNING id;
                    """,
                    (event_id, seat_id, user_id),
                )
                reservation_id = cur.fetchone()[0]

                conn.commit()

    except HTTPException:
        raise

    except errors.ForeignKeyViolation:
        raise HTTPException(400, "Invalid event_id or user_id")

    except Exception:
        raise HTTPException(500, "Reservation failed")

    return {
        "reservation_id": str(reservation_id),
        "status": "confirmed",
    }
