from sqlmodel import SQLModel
from app.models.event import Event
from app.models.reservation import Reservation

# SQLModel scans these on import
